import numpy as np
import pandas as pd
import mdtraj as md
import matplotlib.pyplot as plt
from anarci import anarci
from scipy.spatial.distance import pdist, squareform

# -----------------------------
# INPUT
# -----------------------------
pdb_file = "minimized.pdb"

sequences = {
    'H': 'EVQLVESGGGVVQPGGSLRLSCAASGFTFNSYGMHWVRQAPGKGLEWVAFIRYDGGNKYYADSVKGRFTISRDNSKNTLYLQMKSLRAEDTAVYYCANLKDSRYSGSYYDYWGQGTLVTVS',
    'L': 'VIWMTQSPSSLSASVGDRVTITCQASQDIRFYLNWYQQKPGKAPKLLISDASNMETGVPSRFSGSGSGTDFTFTISSLQPEDIATYYCQQYDNLPFTFGPGTKVDFK'
}

# -----------------------------
# 1. ANARCI (CHAIN-AWARE)
# -----------------------------
print("Running ANARCI...")

cdr_labels = {"H": {}, "L": {}}

for chain, seq in sequences.items():
    result = anarci([(chain, seq)], scheme="imgt")
    numbering = result[0][0][0][0]

    seq_idx = 0
    for pos, aa in numbering:
        if pos is None:
            continue

        resnum = pos[0]

        if 27 <= resnum <= 38:
            region = "CDR1"
        elif 56 <= resnum <= 65:
            region = "CDR2"
        elif 105 <= resnum <= 117:
            region = "CDR3"
        else:
            region = "FR"

        cdr_labels[chain][seq_idx] = region
        seq_idx += 1

# -----------------------------
# 2. STRUCTURE
# -----------------------------
traj = md.load(pdb_file)
top = traj.topology

atoms = list(top.atoms)
residues = list(top.residues)
coords = traj.xyz[0]

# -----------------------------
# 3. SASA
# -----------------------------
print("Calculating SASA...")
sasa = md.shrake_rupley(traj, mode='residue')[0]

# assign chain mapping based on order
chain_seq_idx = {"H": 0, "L": 0}

residue_info = []

for i, res in enumerate(residues):

    # determine chain (simple split assumption)
    if i < len(sequences["H"]):
        chain_label = "H"
        seq_idx = chain_seq_idx["H"]
        chain_seq_idx["H"] += 1
    else:
        chain_label = "L"
        seq_idx = chain_seq_idx["L"]
        chain_seq_idx["L"] += 1

    region = cdr_labels[chain_label].get(seq_idx, "FR")

    residue_info.append({
        "chain": chain_label,
        "resid": i,
        "resname": res.name,
        "sasa": sasa[i],
        "region": region
    })

df = pd.DataFrame(residue_info)

# -----------------------------
# 4. HYDROPHOBIC PATCH (FIXED)
# -----------------------------
hydrophobic = {'ALA','VAL','LEU','ILE','MET','PHE','TRP','PRO'}

# residue centers
coords_res = []
for res in residues:
    atom_idx = [a.index for a in res.atoms]
    coords_res.append(coords[atom_idx].mean(axis=0))

coords_res = np.array(coords_res)

dist_res = squareform(pdist(coords_res))

hydro_patch = []

for i, res in enumerate(residues):
    if res.name not in hydrophobic:
        hydro_patch.append(0)
        continue

    neighbors = np.where(dist_res[i] < 8.0)[0]

    score = sum(
        df.loc[n, "sasa"]
        for n in neighbors
        if residues[n].name in hydrophobic
    )

    hydro_patch.append(score)

df["hydrophobic_patch"] = hydro_patch

# -----------------------------
# 5. ELECTROSTATIC PATCH (IMPROVED)
# -----------------------------
pos_res = {'LYS','ARG','HIS'}
neg_res = {'ASP','GLU'}

charge_list = []

for res in residues:
    if res.name in pos_res:
        charge_list.append(1)
    elif res.name in neg_res:
        charge_list.append(-1)
    else:
        charge_list.append(0)

df["charge"] = charge_list

charge_patch = []

for i in range(len(residues)):
    neighbors = np.where(dist_res[i] < 6.0)[0]  # tighter neighborhood
    charge_patch.append(np.mean([charge_list[n] for n in neighbors]))

df["charge_patch"] = charge_patch

# -----------------------------
# 6. HOTSPOT DETECTION ?
# -----------------------------
print("Identifying aggregation hotspots...")

# define risk score (weighted)
df["agg_score"] = (
    df["hydrophobic_patch"] * 1.5 +
    df["sasa"] * 2.0 +
    np.maximum(df["charge_patch"], 0)  # positive patches more sticky
)

# pick top 10
hotspots = df.sort_values("agg_score", ascending=False).head(10)

print("\nTop 10 aggregation hotspots:")
print(hotspots[["chain", "resid", "resname", "region", "agg_score"]])

# save
hotspots.to_csv("aggregation_hotspots_top10.csv", index=False)

# -----------------------------
# 7. OUTPUT
# -----------------------------
df.to_csv("residue_developability.csv", index=False)

# -----------------------------
# 8. PLOTS
# -----------------------------
def plot_metric(values, title, ylabel, fname):
    plt.figure(figsize=(10,4))
    plt.plot(values)
    plt.title(title)
    plt.xlabel("Residue index")
    plt.ylabel(ylabel)
    plt.tight_layout()
    plt.savefig(fname, dpi=300)
    plt.close()

plot_metric(df["sasa"], "Per-residue SASA", "SASA", "sasa.png")
plot_metric(df["hydrophobic_patch"], "Hydrophobic patch", "Score", "hydropatch.png")
plot_metric(df["charge_patch"], "Charge patch", "Charge", "chargepatch.png")

# hotspot overlay plot
plt.figure(figsize=(10,4))
plt.plot(df["agg_score"], label="Agg score")
plt.scatter(hotspots["resid"], hotspots["agg_score"], color="red", label="Hotspots")
plt.legend()
plt.title("Aggregation hotspot map")
plt.savefig("aggregation_hotspots.png", dpi=300)
plt.close()

print("\nSaved:")
print(" - residue_developability.csv")
print(" - aggregation_hotspots_top10.csv")
print(" - sasa.png, hydropatch.png, chargepatch.png, aggregation_hotspots.png")

# -----------------------------
# 9. SUMMARY
# -----------------------------
print("\n=== SUMMARY ===")
print("Mean SASA:", df["sasa"].mean())
print("Max hydrophobic patch:", df["hydrophobic_patch"].max())
print("Charge patch range:", df["charge_patch"].min(), df["charge_patch"].max())
print("Max aggregation score:", df["agg_score"].max())


print("\nRunning developability liability detection...")

# full sequence (H + L)
full_seq = sequences["H"] + sequences["L"]

# initialize columns
df["deamidation"] = 0
df["isomerization"] = 0
df["oxidation"] = 0
df["glycation"] = 0
df["nglyc"] = 0
df["asp_pro"] = 0
df["free_cys"] = 0
df["protease"] = 0

# helper
def is_exposed(i, threshold=0.5):
    return df.loc[i, "sasa"] > threshold

# sequence scan
for i in range(len(full_seq)):

    aa = full_seq[i]
    next_aa = full_seq[i+1] if i+1 < len(full_seq) else None
    next2_aa = full_seq[i+2] if i+2 < len(full_seq) else None

    # ---- Deamidation (NXS/T, X!=P) ----
    if (
        aa == "N"
        and next_aa != "P"
        and next2_aa in ["S", "T"]
        and is_exposed(i)
    ):
        df.loc[i, "deamidation"] = 1

    # ---- Asp isomerization ----
    if aa == "D" and next_aa in ["G", "S"] and is_exposed(i):
        df.loc[i, "isomerization"] = 1

    # ---- Asp-Pro cleavage ----
    if aa == "D" and next_aa == "P":
        df.loc[i, "asp_pro"] = 1

    # ---- Oxidation ----
    if aa in ["M", "W", "H"] and is_exposed(i):
        df.loc[i, "oxidation"] = 1

    # ---- Glycation (K) ----
    if aa == "K" and is_exposed(i):
        df.loc[i, "glycation"] = 1

    # ---- N-glycosylation ----
    if (
        aa == "N"
        and next_aa != "P"
        and next2_aa in ["S", "T"]
    ):
        df.loc[i, "nglyc"] = 1

    # ---- General protease liability ----
    if (
        aa in ["L", "V", "F", "Y", "W"] and
        is_exposed(i) and
        df.loc[i, "region"] == "CDR"
    ):
        df.loc[i, "protease"] = 1

# ---- Pyroglutamate (N-term only) ----
if full_seq[0] in ["Q", "E"]:
    df.loc[0, "pyroglu"] = 1
else:
    df["pyroglu"] = 0

# ---- Free cysteine ----
# approximate: all cysteines flagged (better: detect disulfides)
for i, aa in enumerate(full_seq):
    if aa == "C":
        df.loc[i, "free_cys"] = 1

# ---- C-terminal Lys ----
df["cterm_lys"] = 0
if full_seq[-1] == "K":
    df.loc[len(full_seq)-1, "cterm_lys"] = 1

print("\n=== LIABILITY SUMMARY ===")

liability_cols = [
    "deamidation", "isomerization", "oxidation", "glycation",
    "nglyc", "asp_pro", "free_cys", "protease"
]

summary = {}

for col in liability_cols:
    summary[col] = int(df[col].sum())

for k, v in summary.items():
    print(f"{k}: {v}")




liability_res = df[
    (df["deamidation"] == 1) |
    (df["isomerization"] == 1) |
    (df["oxidation"] == 1) |
    (df["glycation"] == 1) |
    (df["nglyc"] == 1) |
    (df["protease"] == 1)
]

liability_res.to_csv("liability_hotspots.csv", index=False)

print("\nSaved: liability_hotspots.csv")
