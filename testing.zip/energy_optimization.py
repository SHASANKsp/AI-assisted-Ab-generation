from openmm.app import *
from openmm import *
from openmm.unit import *

pdb = PDBFile('my_antibody.pdb')
forcefield = ForceField('amber14-all.xml')

system = forcefield.createSystem(pdb.topology)

integrator = LangevinIntegrator(300*kelvin, 1/picosecond, 0.002*picoseconds)
simulation = Simulation(pdb.topology, system, integrator)

simulation.context.setPositions(pdb.positions)

print("Minimizing structure...")
simulation.minimizeEnergy()

state = simulation.context.getState(getPositions=True)

with open("minimized.pdb", "w") as f:
    PDBFile.writeFile(pdb.topology, state.getPositions(), f)