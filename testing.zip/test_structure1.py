from Bio.PDB import PDBParser

parser = PDBParser(QUIET=True)
structure = parser.get_structure("ab", "my_antibody.pdb")

# Basic checks
chains = list(structure.get_chains())
print("Chains:", [c.id for c in chains])

atoms = list(structure.get_atoms())
print("Total atoms:", len(atoms))