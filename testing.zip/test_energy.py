from openmm.app import *
from openmm import *
from openmm.unit import *

pdb = PDBFile('my_antibody.pdb')
forcefield = ForceField('amber14-all.xml')

system = forcefield.createSystem(pdb.topology)
integrator = VerletIntegrator(0.002 * picoseconds)
simulation = Simulation(pdb.topology, system, integrator)
simulation.context.setPositions(pdb.positions)

state = simulation.context.getState(getEnergy=True)
print("Potential Energy:", state.getPotentialEnergy())