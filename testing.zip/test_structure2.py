import MDAnalysis as mda
import numpy as np
from MDAnalysis.analysis.distances import distance_array
from MDAnalysis.analysis.dihedrals import Ramachandran

# ---- Load structure ----
u = mda.Universe("minimized.pdb") #minimized.pdb my_antibody.pdb

# Select only protein atoms (avoid solvents/ions if present)
protein = u.select_atoms("protein")

# ---- 1. Clash calculation (FIXED) ----
from MDAnalysis.lib.distances import capped_distance
import numpy as np

# ---- heavy atoms only ----
heavy = protein.select_atoms("not name H*")
coords = heavy.positions

# get index pairs
pairs = capped_distance(
    coords, coords,
    max_cutoff=1.8,
    min_cutoff=1.2,
    box=None,
    return_distances=False
)

# convert to unique i<j pairs only
pairs = np.array(pairs)

# keep only i < j (removes duplicates + self)
pairs = pairs[pairs[:, 0] < pairs[:, 1]]

clashes = len(pairs)

print("Severe clashes (unique pairs):", clashes)

from MDAnalysis.lib.distances import capped_distance
import numpy as np

heavy = protein.select_atoms("not name H*")

coords = heavy.positions

# Use VERY strict cutoff for REAL clashes
pairs = capped_distance(
    coords, coords,
    max_cutoff=1,   # stricter threshold
    min_cutoff=0,
    box=None,
    return_distances=True
)

pairs_idx, distances = pairs

pairs_idx = np.array(pairs_idx)

# unique pairs only
mask = pairs_idx[:, 0] < pairs_idx[:, 1]
pairs_idx = pairs_idx[mask]
distances = distances[mask]

clashes = len(distances)

print("True severe clashes:", clashes)
len(protein.atoms)



'''
# count only backbone atom clashes
bb = protein.select_atoms("name N CA C O")

coords = bb.positions

from MDAnalysis.lib.distances import capped_distance
import numpy as np

pairs = capped_distance(coords, coords, max_cutoff=1.8, min_cutoff=1.2)

pairs = np.array(pairs)
pairs = pairs[pairs[:,0] < pairs[:,1]]

print("Backbone clashes:", len(pairs))
'''

rama = Ramachandran(protein).run()

angles = rama.results.angles

# Convert to NumPy array (safe handling)
import numpy as np
angles = np.array(angles)

print("Angles shape:", angles.shape)

# Handle different MDAnalysis versions
if angles.ndim == 2:
    # shape: (N, 2) ? (phi, psi)
    phi = angles[:, 0]
    psi = angles[:, 1]

elif angles.ndim == 3:
    # shape: (frames, residues, 2)
    phi = angles[0, :, 0]
    psi = angles[0, :, 1]

else:
    raise ValueError("Unexpected Ramachandran angle format")

# Count valid angles
valid_angles = np.sum(
    (phi > -180) & (phi < 180) &
    (psi > -180) & (psi < 180)
)

print("Ramachandran angles computed:", len(phi))
print("Valid Ramachandran angles:", int(valid_angles))


# ---- 3. Radius of gyration ----
rog = protein.radius_of_gyration()
print("Radius of gyration:", round(rog, 2), "A")



missing_backbone = []

for res in protein.residues:
    atom_names = {atom.name for atom in res.atoms}
    if not {"N", "CA", "C"}.issubset(atom_names):
        missing_backbone.append(res.resid)

print("Residues missing backbone atoms:", len(missing_backbone))


# ---- 5. Chain summary (useful sanity check) ----
print("\nChain summary:")
for seg in u.segments:
    print(f"Chain {seg.segid}: {len(seg.residues)} residues")



import mdtraj as md

traj = md.load("my_antibody.pdb")
ss = md.compute_dssp(traj)

print("Secondary structure counts:", 
      {s: list(ss[0]).count(s) for s in set(ss[0])})